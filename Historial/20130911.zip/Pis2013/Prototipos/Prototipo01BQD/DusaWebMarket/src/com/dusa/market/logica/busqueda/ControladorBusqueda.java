package com.dusa.market.logica.busqueda;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dusa.market.modelo.Producto;
import com.dusa.market.persistencia.FabricaManejadores;
import com.dusa.market.persistencia.busqueda.IManejadorBusqueda;
import com.dusa.market.utils.DusaLogger;

public class ControladorBusqueda implements IControladorBusqueda {

	private boolean debug = false;
	
	
	private IManejadorBusqueda imb;
	
	public ControladorBusqueda() {
		this.imb = new FabricaManejadores().getManejadorBusqueda();
	}
	
	@Override
	public List<Producto> getBusquedaProductos(String busqueda) throws ClassNotFoundException, SQLException {
		
		if (debug)
			DusaLogger.log().info("Buscando -> " + busqueda);
		
		List<Producto> productos = imb.getBusquedaProductos(busqueda);
		
		return productos;
	}

}
