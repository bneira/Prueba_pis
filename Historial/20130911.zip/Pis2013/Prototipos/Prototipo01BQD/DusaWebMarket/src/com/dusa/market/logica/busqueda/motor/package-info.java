/**
 * 
 */
/**
 * @author Seba
 *
 */
package com.dusa.market.logica.busqueda.motor;