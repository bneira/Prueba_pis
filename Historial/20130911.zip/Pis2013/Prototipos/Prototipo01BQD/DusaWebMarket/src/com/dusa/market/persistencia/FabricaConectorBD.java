package com.dusa.market.persistencia;

public class FabricaConectorBD {

	public IConectorBD getConectorBD() {
		
		// Con cambiar ac� es suficiente para conectarse remoto o conectarse local
		return new ConectorBDOracleLocal();
		
	}
	
}
