package com.dusa.market.utils;

import java.util.logging.Level;
import java.util.logging.Logger;

public class DusaLogger {
	
	private Logger logger;
	private static DusaLogger instancia;
	
	private DusaLogger() {
		this.logger = Logger.getLogger("DUSA");
	}
	
	public static DusaLogger log() {
		if (instancia == null)
			instancia = new DusaLogger();
		return instancia;
	}
	
	public void info(String string) {
		this.logger.log(Level.INFO, string);
	}
	
	public void error(String string) {
		this.logger.log(Level.SEVERE, string);
	}
	
	public void error(Throwable thrown) {
		this.logger.log(Level.SEVERE, thrown.getMessage(), thrown);
	}
	
	public void warn(String string) {
		this.logger.log(Level.WARNING, string);
	}
	
	
}
