package com.dusa.market.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConectorBDOracleLocal implements IConectorBD {

	@Override
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
        
		// La siguiente l�nea utiliza el driver para conectar con la base. XE es
        // el nombre de la base de datos creada por defecto
        String url = "jdbc:oracle:thin:@//localhost:1521/XE";
        
        //En la siguiente l�nea sustituyan por datos del usuario creado
        return DriverManager.getConnection(url,"SYSTEM", "pass");
	}

	
	
}
