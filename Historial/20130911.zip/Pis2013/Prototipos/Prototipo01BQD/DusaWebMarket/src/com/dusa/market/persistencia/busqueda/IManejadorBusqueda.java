package com.dusa.market.persistencia.busqueda;

import java.sql.SQLException;
import java.util.List;

import com.dusa.market.modelo.Producto;

public interface IManejadorBusqueda {

	public List<Producto> getBusquedaProductos(String busqueda) throws ClassNotFoundException, SQLException;
	
}
