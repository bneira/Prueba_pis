package com.dusa.market.persistencia.busqueda;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dusa.market.modelo.Producto;
import com.dusa.market.persistencia.FabricaConectorBD;
import com.dusa.market.persistencia.IConectorBD;

public class ManejadorBusqueda implements IManejadorBusqueda {

	private IConectorBD conectorBD;
	
	public ManejadorBusqueda() {
		this.conectorBD = new FabricaConectorBD().getConectorBD();
	}

	@Override
	public List<Producto> getBusquedaProductos(String busqueda) throws ClassNotFoundException, SQLException {
		List<Producto> productos = new ArrayList<Producto>();
		
		Connection con = conectorBD.getConnection();
		PreparedStatement ps = con.prepareStatement("select nombre from clientes where nombre like ?");			// FIXME por ahora los clientes son mis productos
		ps.setString(1, "%" + busqueda + "%");
		ResultSet rs = ps.executeQuery();
		
		while (rs.next()) {
			productos.add(new Producto(rs.getString("nombre")));
		}
		
		ps.close();
		rs.close();
		con.close();
		
		return productos;
	}
	
	
	
}
