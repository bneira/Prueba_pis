package com.dusa.market.logica.busqueda;


public class FabricaControladorBusqueda {

	public IControladorBusqueda getControladorBusqueda() {
		return new ControladorBusqueda();
	}
	
}
