package com.dusa.market.interfaz.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dusa.market.logica.busqueda.FabricaControladorBusqueda;
import com.dusa.market.logica.busqueda.IControladorBusqueda;
import com.dusa.market.modelo.Producto;
import com.dusa.market.utils.DusaLogger;

/**
 * Servlet implementation class BuscarProducto
 */
public class BuscarProducto extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public BuscarProducto() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Producto> productos = new ArrayList<Producto>();
		
		IControladorBusqueda icb = new FabricaControladorBusqueda().getControladorBusqueda();		
		try {
			productos = icb.getBusquedaProductos(request.getParameter("busqueda"));
		} catch (ClassNotFoundException | SQLException e) {
			DusaLogger.log().error(e);
		} 
		
		String listaDeProductos = "<ul>#producto#</ul>";
		for (Producto producto : productos) {
			listaDeProductos = listaDeProductos.replaceAll("#producto#", "<li>" + producto.getDescripcion() + "</li>#producto#");
		}		
		listaDeProductos = listaDeProductos.replaceAll("#producto#", "");
		
		response.setContentType("text/html");

	    PrintWriter out = response.getWriter();
		String title = "Buscar Producto";
	    String docType =
		    "<!doctype html public \"-//w3c//dtd html 4.0 " +
		    "transitional//en\">\n";
	      	      
	    String html = docType +
	            "<html>\n" +
	        "<head><title>" + title + "</title></head>\n" +
	        "<body bgcolor=\"#f0f0f0\">\n" +
	        "<h1 align=\"center\">" + title + "</h1>\n" +
	        "<div style='align: center;'>" + listaDeProductos + "</div>\n" +
            "</body></html>";
	      
	      out.println(html);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
