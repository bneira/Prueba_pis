package com.dusa.market.utils;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public class Propiedades {

	/**
	 * Devuelve la propiedad de un archivo.properties
	 * 
	 * @param propiedad
	 * @param archivo
	 * @return
	 */
	public String getPropiedad(String propiedad, String archivo) {
		throw new NotImplementedException();
	}
	
}
