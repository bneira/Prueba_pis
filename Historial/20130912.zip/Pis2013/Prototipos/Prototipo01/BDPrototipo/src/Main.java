
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Main {

    public static void main(String[] parametro) throws SQLException, ClassNotFoundException {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        // La siguiente l�nea utiliza el driver para conectar con la base. XE es
        // el nombre de la base de datos creada por defecto
        String url = "jdbc:oracle:thin:@//localhost:1521/XE";
        //En la siguiente l�nea sustituyan por datos del usuario creado
        Connection conn = DriverManager.getConnection(url,"USER", "pass");
        Statement stmt = conn.createStatement();
        // Esta consulta deber� corresponderse con la tabla que hayan creado, por ejemplo: clientes
        ResultSet rset = stmt.executeQuery("select nombre from clientes");
        while (rset.next()) {
        	// Imprimimos el resultado de nuestra consulta para obtener los datos que insertamos
        	System.out.println (rset.getString("nombre"));
        }
    }
}
