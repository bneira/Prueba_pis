delete clientes;
delete stock;
delete grupos;
delete ivas_cfe;
delete cods_vto;
delete repartos;