package com.dusa.market.logica.busqueda;

import java.sql.SQLException;
import java.util.List;

import com.dusa.market.modelo.Producto;

public interface IControladorBusqueda {

	public List<Producto> getBusquedaProductos(String busqueda) throws ClassNotFoundException, SQLException;
	
}
