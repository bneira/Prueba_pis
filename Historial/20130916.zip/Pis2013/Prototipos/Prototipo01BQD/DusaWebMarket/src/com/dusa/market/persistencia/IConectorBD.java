package com.dusa.market.persistencia;

import java.sql.Connection;
import java.sql.SQLException;

public interface IConectorBD {

	public Connection getConnection() throws ClassNotFoundException, SQLException;
	
}
