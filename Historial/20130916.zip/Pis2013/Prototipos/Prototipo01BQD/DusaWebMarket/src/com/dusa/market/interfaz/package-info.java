/**
 * 
 */
/**
 * @author Seba
 *
 */
package com.dusa.market.interfaz;