package com.dusa.market.persistencia;

import java.sql.Connection;

public class ConectorBDOracleRemoto implements IConectorBD {

	@Override
	public Connection getConnection() {
		return null;
	}

}
