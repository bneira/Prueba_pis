package com.dusa.market.modelo;

public class Producto {

	String descripcion;
	
	public Producto(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
		
	@Override
	public String toString() {
		return this.descripcion;
	}
	
}
