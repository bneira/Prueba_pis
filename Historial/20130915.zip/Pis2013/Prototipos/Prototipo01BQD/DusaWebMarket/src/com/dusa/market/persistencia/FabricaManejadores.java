package com.dusa.market.persistencia;

import com.dusa.market.persistencia.busqueda.IManejadorBusqueda;
import com.dusa.market.persistencia.busqueda.ManejadorBusqueda;

public class FabricaManejadores {

	public IManejadorBusqueda getManejadorBusqueda() {
		return new ManejadorBusqueda();
	}
	
}
